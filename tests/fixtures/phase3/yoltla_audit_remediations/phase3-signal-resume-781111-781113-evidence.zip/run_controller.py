#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

from siestaflow.execution.allocation_controller import AllocationController


root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("--resume", action="store_true")
args = parser.parse_args()
if args.resume:
    os.environ["SIESTAFLOW_RESUME_MODE"] = "1"
status = AllocationController.from_file(root / "campaign.json").run(install_signal_handlers=True)
summary = {"job_id": os.environ.get("SLURM_JOB_ID"), "mode": "resume" if args.resume else "interrupt", "status": status.value}
(root / "results").mkdir(exist_ok=True)
(root / "results" / f"signal_resume_{summary['mode']}.json").write_text(json.dumps(summary, sort_keys=True, indent=2) + "\n", encoding="utf-8")
print(json.dumps(summary, sort_keys=True))
raise SystemExit(0 if status.value in {"INTERRUPTED", "COMPLETED"} else 2)
