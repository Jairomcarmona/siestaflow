#!/usr/bin/env bash
set -euo pipefail
echo "MODE=${SIESTAFLOW_RESUME_MODE:-interrupt}"
if [ "${SIESTAFLOW_RESUME_MODE:-}" = "1" ]; then
  echo "RESUMED_TASK_COMPLETED"
  exit 0
fi
exec sleep 300
