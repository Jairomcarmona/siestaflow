#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import os
import threading
import time
from pathlib import Path

from siestaflow.execution.allocation_controller import AllocationController, ExecutionStatus
from siestaflow.execution.slurm_environment import ShutdownRequest, SlurmEnvironment
from siestaflow.execution.srun_launcher import StepLaunchSpec, StepOutcome


ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def state(root: Path) -> dict:
    return json.loads((root / "state" / "campaign_state.json").read_text(encoding="utf-8"))["payload"]


class ScriptedLauncher:
    def __init__(self, *, ignore_sleep: bool = False) -> None:
        self.ignore_sleep = ignore_sleep
        self.calls: list[dict] = []
        self._active: set[str] = set()
        self._terminate = threading.Event()
        self._barrier = threading.Event()
        self._lock = threading.Lock()

    def launch(self, spec: StepLaunchSpec) -> StepOutcome:
        behavior = spec.input_path.read_text(encoding="utf-8").strip()
        started = time.monotonic()
        active_id = f"{spec.task_id}:{spec.attempt_id}"
        with self._lock:
            self._active.add(active_id)
            self.calls.append({"task_id": spec.task_id, "hosts": list(spec.hosts)})
            if behavior == "BARRIER" and len(self._active) >= 2:
                self._barrier.set()
        if behavior == "BARRIER" and not self._barrier.wait(timeout=5):
            raise RuntimeError("independent tasks did not overlap")
        if behavior == "SLEEP" and not self.ignore_sleep:
            deadline = time.monotonic() + 5
            while time.monotonic() < deadline and not self._terminate.wait(0.02):
                pass
        terminated = self._terminate.is_set()
        output = ["Version: 5.4.2", "Reading input FDF", "SCF iteration 1"]
        exit_code = 143 if terminated else (7 if behavior == "FAIL" else 0)
        if behavior == "ARTIFACT" and not terminated:
            (spec.workdir / "required.DM").write_text("dm", encoding="utf-8")
        if behavior == "RESTART" and not terminated:
            if (spec.workdir / "required.DM").read_text(encoding="utf-8") != "dm":
                raise RuntimeError("restart DM content mismatch")
            output.append("Attempting to read DM from file... Succeeded...")
        if exit_code == 0:
            output.extend(("SCF converged", "Job completed"))
        spec.stdout_path.write_text("\n".join(output) + "\n", encoding="utf-8")
        spec.stderr_path.write_text("controlled failure\n" if exit_code == 7 else "", encoding="utf-8")
        with self._lock:
            self._active.discard(active_id)
        return StepOutcome(
            spec.task_id,
            spec.attempt_id,
            ("phase3-scripted-launcher", behavior),
            exit_code,
            time.monotonic() - started,
            terminated,
        )

    def terminate_all(self, *, kill: bool = False) -> tuple[str, ...]:
        self._terminate.set()
        with self._lock:
            return tuple(sorted(self._active))


class TamperTransferController(AllocationController):
    tamper_mode = "alter"

    def _transfer_inputs(self, task, attempt):
        records = super()._transfer_inputs(task, attempt)
        for transfer in task.transfers:
            destination = attempt / transfer.destination
            if self.tamper_mode == "delete":
                destination.unlink()
            else:
                destination.write_text("altered", encoding="utf-8")
        return records


def actual_hosts() -> tuple[str, ...]:
    if os.environ.get("SLURM_JOB_ID"):
        return SlurmEnvironment.from_mapping().resolve_hostnames()
    return ("tt-test-1", "tt-test-2", "tt-test-3", "tt-test-4")


HOSTS = actual_hosts()
BASE_JOB_ID = os.environ.get("SLURM_JOB_ID", "local-matrix")


def case_environment(root: Path, suffix: str) -> dict[str, str]:
    values = dict(os.environ)
    values.update({
        "SLURM_JOB_ID": f"{BASE_JOB_ID}-{suffix}",
        "SLURM_SUBMIT_DIR": str(root.resolve()),
        "SLURM_JOB_END_TIME": str(time.time() + 600),
        "SLURM_NNODES": "4",
        "SLURM_NTASKS": "4",
        "SLURM_CPUS_PER_TASK": "1",
        "SIESTAFLOW_HOSTS": ",".join(HOSTS),
    })
    return values


def write_case(root: Path, tasks: list[dict], *, max_parallel: int = 2) -> Path:
    root.mkdir(parents=True)
    protected = root / "protected"
    protected.mkdir()
    pseudo = protected / "C.psml"
    pseudo.write_text("technical fixture", encoding="utf-8")
    rendered = []
    for item in tasks:
        source = protected / f"{item['task_id']}.fdf"
        source.write_text(item.pop("behavior") + "\n", encoding="utf-8")
        task = {
            "task_id": item["task_id"],
            "input": f"protected/{source.name}",
            "input_hashes": {
                f"protected/{source.name}": sha256(source),
                "protected/C.psml": sha256(pseudo),
            },
            "input_destinations": {
                f"protected/{source.name}": "input.fdf",
                "protected/C.psml": "C.psml",
            },
            "required_artifacts": item.get("required_artifacts", []),
            "optional_artifacts": [],
            "mpi_processes": item.get("mpi_processes", 4),
            "cpus_per_process": 1,
            "nodes": item.get("nodes", 4),
            "estimated_runtime_seconds": 1,
            "max_attempts": item.get("max_attempts", 2),
            "require_scf_converged": True,
            "depends_on": item.get("depends_on", []),
            "transfers": item.get("transfers", []),
        }
        rendered.append(task)
    campaign = {
        "schema_version": "2.0",
        "campaign_id": root.name,
        "system_id": "phase3-adversarial-technical-matrix",
        "slurm": {"partition": "tt2d-80p", "account": "vini", "qos": "normal"},
        "resources": {
            "nodes": 4,
            "total_cpus": 4,
            "memory": "1000M",
            "walltime": "00:10:00",
            "max_parallel_steps": max_parallel,
            "shutdown_margin_seconds": 1,
            "termination_grace_seconds": 0.01,
        },
        "runtime": {
            "module_commands": [],
            "siesta_executable": "technical-scripted-launcher",
            "executable_arguments": [],
            "launcher": {
                "kind": "hydra",
                "command": ["mpiexec.hydra"],
                "arguments": [],
                "bootstrap": "ssh",
                "processes_per_node": 1,
            },
            "exclusive": True,
            "environment": {},
        },
        "task_policy": {"max_attempts": 2, "require_scf_converged": True},
        "tasks": rendered,
    }
    path = root / "campaign.yaml"
    path.write_text(json.dumps(campaign, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    return path


def run_controller(campaign: Path, suffix: str, launcher: ScriptedLauncher, *, controller_type=AllocationController, shutdown=None):
    return controller_type.from_file(
        campaign,
        environment=case_environment(campaign.parent, suffix),
        launcher=launcher,
        shutdown=shutdown,
        poll_interval_seconds=0.01,
    ).run(install_signal_handlers=False)


def failed_parent_case(root: Path) -> dict:
    launcher = ScriptedLauncher()
    campaign = write_case(root, [
        {"task_id": "parent", "behavior": "FAIL"},
        {"task_id": "child", "behavior": "SUCCESS", "depends_on": ["parent"]},
    ])
    result = run_controller(campaign, "failed-parent", launcher)
    tasks = state(root)["tasks"]
    assert result is ExecutionStatus.FAILED
    assert tasks["parent"]["status"] == "FAILED"
    assert tasks["child"]["status"] == "BLOCKED" and tasks["child"]["attempts"] == 0
    assert [item["task_id"] for item in launcher.calls] == ["parent"]
    return {"status": "PASS", "observed": {"parent": "FAILED", "child": "BLOCKED", "child_attempts": 0}}


def absent_dm_case(root: Path) -> dict:
    launcher = ScriptedLauncher()
    transfer = {"from_task": "parent", "artifact": "required.DM", "destination": "required.DM"}
    campaign = write_case(root, [
        {"task_id": "parent", "behavior": "SUCCESS", "required_artifacts": ["required.DM"]},
        {"task_id": "child", "behavior": "RESTART", "depends_on": ["parent"], "transfers": [transfer]},
    ])
    result = run_controller(campaign, "absent-dm", launcher)
    tasks = state(root)["tasks"]
    assert result is ExecutionStatus.INCOMPLETE
    assert tasks["parent"]["status"] == "INCOMPLETE"
    assert tasks["child"]["attempts"] == 0
    assert [item["task_id"] for item in launcher.calls] == ["parent"]
    return {"status": "PASS", "observed": {"parent": "INCOMPLETE", "child_attempts": 0}}


def altered_hash_case(root: Path) -> dict:
    launcher = ScriptedLauncher()
    transfer = {"from_task": "parent", "artifact": "required.DM", "destination": "required.DM"}
    campaign = write_case(root, [
        {"task_id": "parent", "behavior": "ARTIFACT", "required_artifacts": ["required.DM"]},
        {"task_id": "child", "behavior": "RESTART", "depends_on": ["parent"], "transfers": [transfer]},
    ])
    result = run_controller(campaign, "altered-hash", launcher, controller_type=TamperTransferController)
    tasks = state(root)["tasks"]
    assert result is ExecutionStatus.FAILED
    assert tasks["parent"]["status"] == "COMPLETED"
    assert tasks["child"]["status"] == "FAILED"
    assert "transferred input changed before launch" in tasks["child"]["reason"]
    assert [item["task_id"] for item in launcher.calls] == ["parent"]
    return {"status": "PASS", "observed": {"parent": "COMPLETED", "child": "FAILED_BEFORE_LAUNCH"}}


def interruption_recovery_case(root: Path) -> dict:
    campaign = write_case(root, [{"task_id": "task", "behavior": "SLEEP", "max_attempts": 2}])
    shutdown = ShutdownRequest()
    first_launcher = ScriptedLauncher()
    timer = threading.Timer(0.05, lambda: shutdown.request("SIGUSR1"))
    timer.start()
    try:
        first = run_controller(campaign, "interrupt", first_launcher, shutdown=shutdown)
    finally:
        timer.cancel()
    assert first is ExecutionStatus.INTERRUPTED
    second_launcher = ScriptedLauncher(ignore_sleep=True)
    second = run_controller(campaign, "resume", second_launcher)
    saved = state(root)
    assert second is ExecutionStatus.COMPLETED
    assert saved["tasks"]["task"]["attempts"] == 2
    assert len(saved["allocation_history"]) == 2
    return {"status": "PASS", "observed": {"first": "INTERRUPTED", "resumed": "COMPLETED", "attempts": 2}}


def independent_nonoverlap_case(root: Path) -> dict:
    launcher = ScriptedLauncher()
    campaign = write_case(root, [
        {"task_id": "left", "behavior": "BARRIER", "nodes": 2, "mpi_processes": 2},
        {"task_id": "right", "behavior": "BARRIER", "nodes": 2, "mpi_processes": 2},
    ], max_parallel=2)
    result = run_controller(campaign, "nonoverlap", launcher)
    assert result is ExecutionStatus.COMPLETED
    hosts = {item["task_id"]: set(item["hosts"]) for item in launcher.calls}
    assert len(hosts["left"]) == len(hosts["right"]) == 2
    assert hosts["left"].isdisjoint(hosts["right"])
    assert hosts["left"] | hosts["right"] == set(HOSTS)
    return {"status": "PASS", "observed": {key: sorted(value) for key, value in hosts.items()}}


def main() -> int:
    if RESULTS.exists():
        raise SystemExit("REFUSING_OVERWRITE_EXISTING_MATRIX_RESULTS")
    cases_root = RESULTS / "cases"
    cases_root.mkdir(parents=True)
    functions = {
        "failed_parent_blocks_child": failed_parent_case,
        "absent_dm_prevents_child": absent_dm_case,
        "altered_hash_prevents_child_launch": altered_hash_case,
        "interruption_is_recoverable": interruption_recovery_case,
        "independent_tasks_use_disjoint_hosts": independent_nonoverlap_case,
    }
    report = {
        "schema_version": "1.0",
        "classification": "REAL_REMOTE_TECHNICAL_ADVERSARIAL_EVIDENCE" if os.environ.get("SLURM_JOB_ID") else "LOCAL_TECHNICAL_ADVERSARIAL_EVIDENCE",
        "job_id": os.environ.get("SLURM_JOB_ID"),
        "hosts": list(HOSTS),
        "source_commit": "594e0e5",
        "scientific_calculation_performed": False,
        "cases": {},
    }
    for name, function in functions.items():
        try:
            report["cases"][name] = function(cases_root / name)
        except Exception as exc:
            report["cases"][name] = {"status": "FAIL", "error": f"{type(exc).__name__}: {exc}"}
    report["status"] = "PASS" if all(item["status"] == "PASS" for item in report["cases"].values()) else "FAIL"
    (RESULTS / "phase3_adversarial_matrix.json").write_text(json.dumps(report, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, sort_keys=True))
    return 0 if report["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
