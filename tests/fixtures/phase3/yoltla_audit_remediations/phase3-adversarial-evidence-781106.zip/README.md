# Phase 3 Yoltla adversarial matrix with raw evidence collection

Technical validation companion for the canonical positive-path acceptance.
It uses the allocation controller from source commit `594e0e5` and performs no
scientific calculation. One four-node Slurm job verifies:

- failed parent blocks its child;
- absent required DM prevents child launch;
- altered transferred-DM hash prevents child launch;
- controlled interruption can be reconciled and resumed;
- independent tasks receive disjoint host sets.

Run only from this directory:

```bash
python3 verify_package.py
sbatch --test-only submit.slurm
sbatch submit.slurm
```

After terminal completion, preserve raw post-job evidence:

```bash
sacct -j <JOB_ID> --format=JobID,State,ExitCode,Elapsed,NodeList > evidence/slurm-sacct-<JOB_ID>.txt
python3 finalize_evidence.py --job-id <JOB_ID>
```

Success requires Slurm exit `0:0` and
`results/phase3_adversarial_matrix.json` with top-level `status: PASS` and five
case-level `PASS` values.
