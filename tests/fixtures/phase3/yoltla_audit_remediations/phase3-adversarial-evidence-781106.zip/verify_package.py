#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import re
import subprocess
from pathlib import Path, PurePosixPath


ROOT = Path(__file__).resolve().parent


def fail(code: str, detail: str = "") -> None:
    raise SystemExit(code + (":" + detail if detail else ""))


seen: set[str] = set()
for line in (ROOT / "checksums.sha256").read_text(encoding="utf-8").splitlines():
    match = re.fullmatch(r"([0-9a-f]{64})  (.+)", line)
    if match is None:
        fail("INVALID_CHECKSUM_LINE", line)
    expected, name = match.groups()
    relative = PurePosixPath(name)
    if relative.is_absolute() or ".." in relative.parts or "\\" in name or name in seen:
        fail("UNSAFE_CHECKSUM_PATH", name)
    seen.add(name)
    target = ROOT.joinpath(*relative.parts)
    if not target.is_file() or target.is_symlink():
        fail("MISSING_PACKAGE_FILE", name)
    if hashlib.sha256(target.read_bytes()).hexdigest() != expected:
        fail("PACKAGE_HASH_MISMATCH", name)
actual = {
    path.relative_to(ROOT).as_posix()
    for path in ROOT.rglob("*")
    if path.is_file()
    and path.name != "checksums.sha256"
    and path.relative_to(ROOT).parts[0] not in {"results", "evidence"}
    and not path.name.startswith(("OUT.", "ERROR."))
}
if actual != seen:
    fail("CHECKSUM_COVERAGE_MISMATCH", str(sorted(actual ^ seen)))
compile(ROOT.joinpath("run_matrix.py").read_text(encoding="utf-8"), "run_matrix.py", "exec")
syntax = subprocess.run(["bash", "-n", "submit.slurm"], cwd=ROOT, capture_output=True, text=True)
if syntax.returncode:
    fail("BASH_SYNTAX_FAILURE", syntax.stderr.strip())
print("PHASE3_ADVERSARIAL_MATRIX_PACKAGE_VERIFIED")
print("NO_SCIENTIFIC_CALCULATION_CONFIGURED")
